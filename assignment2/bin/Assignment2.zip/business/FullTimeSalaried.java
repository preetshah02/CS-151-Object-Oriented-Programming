package business;
/**
 * 
 * This class inherits from the abstract class FullTimeEmployee and computes the pay of a salaried employee 
 * based on the number of weeks they worked.
 * 
 * @author Preet LNU
 * @version 2022-03-02
 * 
 */
public class FullTimeSalaried extends FullTimeEmployee
{
	public FullTimeSalaried()
	{
		super();
	}
	
	public FullTimeSalaried(String firstName, String lastName, Address address, int id, double salary, String ssn)
	{
		super(firstName, lastName, address, id, salary, ssn);
	}
	
	@Override
	public String toString()
	{
		return super.toString();
	}
	
	public void introduce(boolean displaySSN) 
	{
        if (displaySSN) 
        {
            System.out.println(toString() + "\n SSN: " + getSSN());
        }  
        else 
        {
            System.out.println(toString());
        }
    }
	
	
	public double computePay(int numWeeks)
	{
		return getBasePay() * 1 / 52 * numWeeks;
	}
}
