package business;
/**
 * 
 * This abstract class gets and sets all the basic information about a person which will be
 * used in this project.
 * 
 * @author Preet LNU
 * @version 2022-03-02
 * 
 */
public abstract class Person 
{
	//instance variables
	private String firstName;
	private String lastName;
	private int age;
	private String ssn;
	private Address address;

	public Person()
	{
		
	}
	
	public Person(String firstName, String lastName, Address address, String ssn)
	{
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.ssn = ssn;
	}
	
	public String getFirstName()
	{
		return firstName;
	}
	
	public String getLastName()
	{
		return lastName;
	}
	
	public int getAge()
	{
		return age;
	}
	
	public String getSSN()
	{
		return ssn;
	}
	
	public Address getAddress()
	{
		return address;
	}
	
	public void setFirstName(String fname)
	{
		firstName = fname;
	}
	
	public void setLastName(String lname)
	{
		lastName = lname;
	}
	
	public void setAge(int a)
	{
		age = a;
	}
	
	public void setSSN(String sn)
	{
		ssn = sn;
	}
	
	public void setAddress(Address addr)
	{
		address = addr;
	}
	
	@Override
	public String toString()
	{
		return "Person: " + firstName + " " + lastName + "\n age: " + age + "\n Address: " + address;
	}
}
