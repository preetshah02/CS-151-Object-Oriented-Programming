package business;
/**
 * 
 * This class inherits from the abstract class Employee, sets and gets the hourly pay of a part time employee. 
 * This class also calculates the total pay of the part time employee.
 * 
 * @author Preet LNU
 * @version 2022-03-02
 * 
 */
public class PartTimeHourly extends Employee
{
	//instance variables
	private double baseHourlyPay;
	
	public PartTimeHourly()
	{
		super();
	}
	
	public PartTimeHourly(String firstName, String lastName, Address address, int id, double pay, String ssn)
	{
		super(firstName, lastName, address, id, ssn);
		baseHourlyPay = pay;
	}
	
	public double getHourlyPay()
	{
		return baseHourlyPay;
	}
	
	public void setHourlyPay(double pay)
	{
		baseHourlyPay = pay;
	}
	
	@Override
	public String toString()
	{
		return super.toString() + "\n PartTimeHourly: " + "\n Base Hourly Pay: " + baseHourlyPay;
	}
	
	public void introduce(boolean displaySSN) 
	{
        if (displaySSN) 
        {
            System.out.println(toString() + "\nSSN: " + getSSN());
        } 
        else 
        {
            System.out.println(toString());
        }
    }
	
	public double computePay(int numHrs)
	{
		if(numHrs > 40)
		{
			return -1;
		}
		else
		{
			return baseHourlyPay * numHrs;
		}
	} 
}
