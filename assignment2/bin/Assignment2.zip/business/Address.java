package business;
/**
 * 
 * This class gets and sets the address and then prints it out
 * 
 * @author Preet LNU
 * @version 2022-03-02
 * 
 */
public class Address 
{
	//instance variables
	private int streetNum;
	private String streetName;
	private String city;
	private String zip;
	private String state;
	
	public Address(int streetNum, String streetName, String city, String zip, String state)
	{
		this.streetNum = streetNum;
		this.streetName = streetName;
		this.city = city;
		this.zip = zip;
		this.state = state;
	}
	
	public int getStreetNum()
	{
		return streetNum;
	}
	
	public String getStreetName()
	{
		return streetName;
	}
	
	public String getCity()
	{
		return city;
	}
	
	public String getZip()
	{
		return zip;
	}

	public String getState()
	{
		return state;
	}
	
	public void setStreetNum(int num)
	{
		streetNum = num;
	}
	
	public void setStreetName(String name)
	{
		streetName = name;
	}
	
	public void setZip(String z)
	{
		zip = z;
	}
	
	public void setCity(String cty)
	{
		city = cty;
	}
	
	public void setState(String st)
	{
		state = st;
	}
	
	@Override
	public String toString()
	{
		return  streetNum + ", " + streetName + ", " + city + ", " + state + "- " + zip; 
	}
}
