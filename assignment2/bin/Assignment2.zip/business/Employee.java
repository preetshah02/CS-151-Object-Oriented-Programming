package business;
/**
 * 
 * This abstract class inherits from the class Person and gets and sets the basic information about the employee
 * 
 * @author Preet LNU
 * @version 2022-03-02
 * 
 */
public abstract class Employee extends Person
{
	//instance variables
	private int id;
	private String educationLevel;
	private boolean directDeposit;

	public Employee()
	{
		super();
	}
	
	public Employee(String firstName, String lastName, Address address, int id, String ssn)
	{
		super(firstName, lastName, address, ssn);
		this.id = id;
		
	}
	
	public int getID()
	{
		return id;
	}
	
	public String getEducation()
	{
		return educationLevel;
	}
	
	public boolean getDirectDeposit()
	{
		return directDeposit;
	}
	
	public void setID(int ID)
	{
		id = ID;
	}
	
	public void setEducation(String education)
	{
		educationLevel = education;
	}
	
	public void setDirectDeposit(boolean deposit)
	{
		directDeposit = deposit;
	}
	
	@Override
	public String toString()
	{
		return super.toString() + "\n Employee ID: " + id + "\n Education: " + educationLevel + "\n Direct Deposit: " + directDeposit;
	}
}
