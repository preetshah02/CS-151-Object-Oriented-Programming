package business;
/**
 * 
 * This class inherits from the Employee class and calculates the pay of a contractor while also printing their information
 * 
 * 
 * @author Preet LNU
 * @version 2022-03-02
 * 
 */
public class Contractor extends Employee
{
	//instance variables
	private double basePay;
	
	public Contractor()
	{
		super();
	}
	
	public Contractor(String firstName, String lastName, Address address, int id, double pay, String ssn)
	{
		super(firstName, lastName, address, id, ssn);
		basePay = pay;
	}
	
	public double getBasePay()
	{
		return basePay;
	}
	
	public void setBasePay(double pay)
	{
		basePay = pay;
	}
	
	@Override
	public String toString()
	{
		return super.toString() + "\n Contractor: " + "\n Base Pay: " + basePay;
	}
	
	public void introduce(boolean displaySSN)
	{
        if (displaySSN) 
        {
            System.out.println(toString() + "\nSSN: " + getSSN());
        } 
        else 
        {
            System.out.println(toString());
        }

	}
	
	public double computePay(int numHrs)
	{
		return basePay * numHrs;
	}

}
