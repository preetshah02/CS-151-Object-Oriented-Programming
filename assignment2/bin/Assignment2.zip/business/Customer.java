package business;
/**
 * 
 * This class inherits from the class Person and sets and gets the basic information of the customer 
 * and also provides with the payment preference that the customer chooses.
 * 
 * @author Preet LNU
 * @version 2022-03-02
 * 
 */
public class Customer extends Person
{
	//instance variables
	private int customerID;
	private String payPreference;
	
	public Customer()
	{
		super();
	}
	
	public Customer(String firstName, String lastName, Address address, int id, String ssn)
	{
		super(firstName, lastName, address, ssn);
		customerID = id;
	}
	
	public int getID()
	{
		return customerID;
	}
	
	public void setID(int id)
	{
		customerID = id;
	}
	
	public String getPayPreference()
	{
		return payPreference;
	}
	
	public void setPayPreference(String paymentMethod)
	{
		payPreference = paymentMethod;
	}
	
	@Override
	public String toString()
	{
		return super.toString() + "\n Customer ID: " + customerID + "\n Payment Preference: " + payPreference;
	}
	
	public void introduce(boolean displaySSN) {
        if (displaySSN) 
        {
            System.out.println(toString() + "\n SSN: " + getSSN());
        } 
        else 
        {
            System.out.println(toString());
        }
	}
	
	public void makePayment()
	{
		System.out.println("Payment Method: " + payPreference);
	}
}
